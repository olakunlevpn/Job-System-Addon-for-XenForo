<?php

namespace addons\Olakunlevpn\JobSystem;

class Listener
{

}