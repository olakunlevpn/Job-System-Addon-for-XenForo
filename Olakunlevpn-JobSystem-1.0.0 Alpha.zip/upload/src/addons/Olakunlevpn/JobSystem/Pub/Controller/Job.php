<?php

namespace Olakunlevpn\JobSystem\Pub\Controller;


use XF\Api\ControllerPlugin\AttachmentPlugin;
use XF\ControllerPlugin\Attachment;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;
use XF\Repository\AttachmentRepository;

class Job extends AbstractController
{

    public function actionIndex()
    {

        $jobs = $this->getJobRepo()->findActiveJobs()->fetch();

        return $this->view(
            'Olakunlevpn\JobSystem:Job\Index',
            'olakunlevpn_job_system_welcome',
            ['jobs' => $jobs]
        );
    }

    public function actionView(ParameterBag $params)
    {

        $jobId = $params->job_id;
        if ($jobId) {
            $job = $this->assertJobExists($jobId);
        } else {
            return $this->message(' The requested job could not be found.');
        }


        $submission = $this->em()->create('Olakunlevpn\JobSystem:Submission');
        $submission->job_id = $job->job_id;
        $submission->user_id = \XF::visitor()->user_id;

        $submissionProcess = $this->em()->findOne('Olakunlevpn\JobSystem:Submission', [
            'job_id' => $jobId,
            'user_id' => \XF::visitor()->user_id
        ]);


        $attachmentRepo = $this->repository('XF:Attachment');
        $attachmentData = $attachmentRepo->getEditorData('job_submission_tasks', $submission);



        $job->details = \XF::app()->bbCode()->render($job->details, 'html', 'job', $job);

        $viewParams = [
            'job' => $job,
            'existingSubmission' => $submissionProcess,
            'attachmentData' => $attachmentData,
            'submission' => $submission,
            'submissionProcess' => $submissionProcess
        ];

        return $this->view(
            'Olakunlevpn\JobSystem:Job\Index',
            'olakunlevpn_job_system_view',
            $viewParams
        );
    }



    public function actionList()
    {
        $page = $this->filterPage();
        $perPage = 10;

        $jobFinder = $this->getJobRepo()->findActiveJobs();
        $totalJobs = $jobFinder->total();



        $jobs = $jobFinder
            ->limitByPage($page, $perPage)
            ->fetch();

        return $this->view(
            'Olakunlevpn\JobSystem:Job\Index',
            'olakunlevpn_job_system_index',
            [
                'jobs' => $jobs,
                'page' => $page,
                'perPage' => $perPage,
                'total' => $totalJobs,
            ]);
    }

    public function actionSubmit(ParameterBag $params)
    {
        $app = \XF::app();

        $jobId = $params->job_id;
        $job = $this->assertJobExists($jobId);
        \XF::session()->set('flashMessage', 'Your submission has been received!');

        $input = $this->filter([
            'submission_text' => 'str',
            'submission_url' => 'str',
            'attachment_hash' => 'str',
        ]);


        $submission = $app->em()->create('Olakunlevpn\JobSystem:Submission');
        $submission->job_id = $jobId;
        $submission->user_id = \XF::visitor()->user_id;


        if ($job->type == 'text') {
            if (empty($input['submission_text'])) {
                return $this->error('Please enter your response for the job.');
            }
            $submission->submission_data = $input['submission_text'];
        } else {
            if (empty($input['submission_url'])) {
                return $this->error('Please enter the URL for your submission.');
            }

            if (!filter_var($input['submission_url'], FILTER_VALIDATE_URL)) {
                return $this->error('Please enter a valid URL.');
            }


            $submission->submission_data = $input['submission_url'];
        }


        $submission->submitted_date = \XF::$time;
        $submission->attachment_hash = $input['attachment_hash'];
        $submission->save();


        $inserter = $this->service(\XF\Service\Attachment\PreparerService::class);
        $associated = $inserter->associateAttachmentsWithContent($input['attachment_hash'], 'job_submission_tasks', $submission->submission_id);
        if (!$associated)
        {
            return $this->error('We are unable to upload your images, please try again later.');
        }

        $this->notifyUserJobPending($submission);


        return $this->redirect($this->buildLink('jobs/view', $job), 'Your submission has been received!');
    }

    protected function notifyUserJobPending($submission)
    {
        $extraData = [
            'message' => "Your job submission is currently pending review. Please wait for further updates."
        ];

        $this->notifyUserJobStatus($submission, 'pending', $extraData);
    }



    protected function notifyUserJobStatus($submission, $action, array $extraData = [])
    {
        /** @var \XF\Repository\UserAlert $userAlertRepo */
        $userAlertRepo = \XF::app()->repository('XF:UserAlert');

        $user = \XF::app()->find('XF:User', $submission->user_id);

        if (!$user) {
            return;
        }

        $defaultExtraData = [
            'depends_on_addon_id' => 'Olakunlevpn/JobSystem',
            'jobTitle' => $submission->Job->title,
        ];

        $extraData = array_merge($defaultExtraData, $extraData);

        $userAlertRepo->alert(
            $user,
            0,
            '',
            'job_submission_tasks',
            $submission->submission_id,
            $action,
            $extraData
        );
    }


    public function actionCompleted()
    {

        $page = $this->filterPage();
        $perPage = 10;

        $jobFinder = $this->getJobRepo()->findApprovedJobs();
        $totalJobs = $jobFinder->total();

        $jobs = $jobFinder
            ->limitByPage($page, $perPage)
            ->fetch();

        return $this->view(
            'Olakunlevpn\JobSystem:Job\Completed',
            'olakunlevpn_job_system_completed',
            [
                'jobs' => $jobs,
                'page' => $page,
                'perPage' => $perPage,
                'total' => $totalJobs,
            ]
        );
    }


    public function actionPending()
    {

        $page = $this->filterPage();
        $perPage = 10;

        $jobFinder = $this->getJobRepo()->findPendingJobs();
        $totalJobs = $jobFinder->total();



        $jobs = $jobFinder
            ->limitByPage($page, $perPage)
            ->fetch();

        return $this->view(
            'Olakunlevpn\JobSystem:Job\Pending',
            'olakunlevpn_job_system_pending',
            [
                'jobs' => $jobs,
                'page' => $page,
                'perPage' => $perPage,
                'total' => $totalJobs,
            ]
        );
    }

    protected function getJobRepo()
    {
        return $this->repository('Olakunlevpn\JobSystem:Job');
    }


    protected function assertJobExists($jobId)
    {
        return $this->assertRecordExists('Olakunlevpn\JobSystem:Job', $jobId);
    }


    protected function getAttachmentRepo()
    {
        return $this->repository('XF:Attachment');
    }


}